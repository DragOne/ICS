/* 
 * CS:APP Data Lab 
 * 
 * Longyi Cheng, LCHENG
 * 
 * bits.c - Source file with your solutions to the Lab.
 *          This is the file you will hand in to your instructor.
 *
 * WARNING: Do not include the <stdio.h> header; it confuses the dlc
 * compiler. You can still use printf for debugging without including
 * <stdio.h>, although you might get a compiler warning. In general,
 * it's not good practice to ignore compiler warnings, but in this
 * case it's OK.  
 */

#if 0
/*
 * Instructions to Students:
 *
 * STEP 1: Read the following instructions carefully.
 */

You will provide your solution to the Data Lab by
editing the collection of functions in this source file.

INTEGER CODING RULES:
 
  Replace the "return" statement in each function with one
  or more lines of C code that implements the function. Your code 
  must conform to the following style:
 
  int Funct(arg1, arg2, ...) {
      /* brief description of how your implementation works */
      int var1 = Expr1;
      ...
      int varM = ExprM;

      varJ = ExprJ;
      ...
      varN = ExprN;
      return ExprR;
  }

  Each "Expr" is an expression using ONLY the following:
  1. Integer constants 0 through 255 (0xFF), inclusive. You are
      not allowed to use big constants such as 0xffffffff.
  2. Function arguments and local variables (no global variables).
  3. Unary integer operations ! ~
  4. Binary integer operations & ^ | + << >>
    
  Some of the problems restrict the set of allowed operators even further.
  Each "Expr" may consist of multiple operators. You are not restricted to
  one operator per line.

  You are expressly forbidden to:
  1. Use any control constructs such as if, do, while, for, switch, etc.
  2. Define or use any macros.
  3. Define any additional functions in this file.
  4. Call any functions.
  5. Use any other operations, such as &&, ||, -, or ?:
  6. Use any form of casting.
  7. Use any data type other than int.  This implies that you
     cannot use arrays, structs, or unions.

 
  You may assume that your machine:
  1. Uses 2s complement, 32-bit representations of integers.
  2. Performs right shifts arithmetically.
  3. Has unpredictable behavior when shifting an integer by more
     than, or equal to, the word size.

EXAMPLES OF ACCEPTABLE CODING STYLE:
  /*
   * pow2plus1 - returns 2^x + 1, where 0 <= x <= 31
   */
  int pow2plus1(int x) {
     /* exploit ability of shifts to compute powers of 2 */
     return (1 << x) + 1;
  }

  /*
   * pow2plus4 - returns 2^x + 4, where 0 <= x <= 31
   */
  int pow2plus4(int x) {
     /* exploit ability of shifts to compute powers of 2 */
     int result = (1 << x);
     result += 4;
     return result;
  }

FLOATING POINT CODING RULES

For the problems that require you to implement floating-point operations,
the coding rules are less strict.  You are allowed to use looping and
conditional control.  You are allowed to use both ints and unsigneds.
You can use arbitrary integer and unsigned constants.

You are expressly forbidden to:
  1. Define or use any macros.
  2. Define any additional functions in this file.
  3. Call any functions.
  4. Use any form of casting.
  5. Use any data type other than int or unsigned.  This means that you
     cannot use arrays, structs, or unions.
  6. Use any floating point data types, operations, or constants.


NOTES:
  1. Use the dlc (data lab checker) compiler (described in the handout) to 
     check the legality of your solutions.
  2. Each function has a maximum number of operators (! ~ & ^ | + << >>)
     that you are allowed to use for your implementation of the function. 
     The max operator count is checked by dlc. Note that '=' is not 
     counted; you may use as many of these as you want without penalty.
  3. Use the btest test harness to check your functions for correctness.
  4. Use the BDD checker to formally verify your functions
  5. The maximum number of ops for each function is given in the
     header comment for each function. If there are any inconsistencies 
     between the maximum ops in the writeup and in this file, consider
     this file the authoritative source.

/*
 * STEP 2: Modify the following functions according the coding rules.
 * 
 *   IMPORTANT. TO AVOID GRADING SURPRISES:
 *   1. Use the dlc compiler to check that your solutions conform
 *      to the coding rules.
 *   2. Use the BDD checker to formally verify that your solutions produce 
 *      the correct answers.
 */


#endif
// Bits
/* 
 * bitMatch - Create mask indicating which bits in x match those in y
 *            using only ~ and & 
 *   Example: bitMatch(0xFF000FF7, 0x0FF00F0E) = 0x0F0FFF06
 *   Legal ops: ~ &
 *   Max ops: 14
 *   Rating: 1
 */
int bitMatch(int x, int y) {
  /*
   * De Morgan's laws: ~(x | y) = ~x & ~y
   */
  int sameBit1 = x & y;
  int sameBit0 = ~x & ~y;
  return ~((~sameBit0)&(~sameBit1));
}
/* 
 * copyLSB - set all bits of result to least significant bit of x
 *   Example: copyLSB(5) = 0xFFFFFFFF, copyLSB(6) = 0x00000000
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 5
 *   Rating: 2
 */
int copyLSB(int x) {
  /*
   * Get the last bit and duplicate it
   * by shift it all the way left then right
   */
  int lastBit = x & 1;
  return lastBit << 31 >> 31;
}
/* 
 * allOddBits - return 1 if all odd-numbered bits in word set to 1
 *   where bits are numbered from 0 (least significant) to 31 (most significant)
 *   Examples allOddBits(0xFFFFFFFD) = 0, allOddBits(0xAAAAAAAA) = 1
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 12
 *   Rating: 2
 */
int allOddBits(int x) {
  /* Create a mask 0xAAAAAAAA 
   * check if x is same with this mask on odd bits
   */
  int aa = 0xAA;
  int aa00 = aa << 8;
  int aaaa = aa00 | 0xAA;
  int aaaa0000 = aaaa << 16;
  int aaaaaaaa = aaaa0000 | aaaa;
  return !((aaaaaaaa & x) ^ aaaaaaaa);
}
/* 
 * conditional - same as x ? y : z 
 *   Example: conditional(2,4,5) = 4
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 16
 *   Rating: 3
 */
int conditional(int x, int y, int z) {
  /*
   * Create a mask of all 0s or all 1s
   * depends on x is 0 or not,
   * if x is true, result is mask & y,
   * else result is ~mask & z.
   */
  int condition = !!x << 31 >> 31;
  int true_then = condition & y;
  int false_else = ~condition & z;
  return true_then | false_else;
}
/*
 * bitParity - returns 1 if x contains an odd number of 1's
 *   Examples: bitParity(5) = 0, bitParity(7) = 1
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 20
 *   Rating: 4
 */
int bitParity(int x) {
 /*
  * XOR can represent parity calculation, 1 = odd, 0 = even,
  * odd ^ even = odd, even ^ odd = odd,
  * even ^ even = even, odd ^ odd = even.
  * Recursively divide bits into two parts
  * and XOR two bits next to each other.
  *
  */
  int next1 = x >> 1 ^ x;
  int next2 = next1 >> 2 ^ next1;
  int next4 = next2 >> 4 ^ next2;
  int next8 = next4 >> 8 ^ next4;
  int next16 = next8 >> 16 ^ next8;
  return next16 & 1;
}
/*
 * isPallindrome - Return 1 if bit pattern in x is equal to its mirror image
 *   Example: isPallindrome(0x0123C480) = 1
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 45
 *   Rating: 4
 */
int isPallindrome(int x) {
 /*
  * reverse left part to right by
  * exchanging left and right parts recursively
  * then XOR new right part with original right part
  */
  int y, mask_ff00ff00, mask_00ff00ff, mask_f0f0f0f0, mask_0f0f0f0f, mask_cccccccc, mask_33333333, mask_aaaaaaaa, mask_55555555, mask_right;

  y = x >> 16;

  mask_ff00ff00 = 0xFF << 8;
  mask_00ff00ff = ~mask_ff00ff00;
  y = ((y & mask_ff00ff00) >> 8) | ((y & mask_00ff00ff) << 8);

  mask_f0f0f0f0 = (0xF << 12) + (0xF << 4);
  mask_0f0f0f0f = ~mask_f0f0f0f0;
  y = ((y & mask_f0f0f0f0) >> 4) | ((y & mask_0f0f0f0f) << 4);

  mask_cccccccc = (0xCC << 8) + 0xCC;
  mask_33333333 = ~mask_cccccccc;
  y = (y & mask_cccccccc) >> 2 | (y & mask_33333333) << 2;

  mask_aaaaaaaa = (0xAA << 8) + 0xAA;
  mask_55555555 = ~mask_aaaaaaaa;
  y = ((y & mask_aaaaaaaa) >> 1) | ((y & mask_55555555) << 1);

  mask_right = (0xFF << 8) + 0xFF;

  x = mask_right & x;
  y = mask_right & y;

  return !(x^y);
}
// Two's complement
/*
 * distinctNegation - returns 1 if x != -x.
 *     and 0 otherwise 
 *   Legal ops: ! ~ & ^ | +
 *   Max ops: 5
 *   Rating: 2
 */
int distinctNegation(int x) {
  /*
   * -x = ~x + 1
   */
  int negativeX = ~x + 1;
  return !!(negativeX ^ x);
}
/* 
 * dividePower2 - Compute x/(2^n), for 0 <= n <= 30
 *  Round toward zero
 *   Examples: dividePower2(15,1) = 7, dividePower2(-33,4) = -2
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 15
 *   Rating: 2
 */
int dividePower2(int x, int n) {
/*
 * add 1 if x less than 0
 */
  return ((x + ((x >> 31) & ((1<<n) + ~0))) >> n);
  // int sign = x >> 31;
  // return ((~sign) & (x >> n)) | ((sign) & ((x + (1<<n) + ~0) >> n));

}
/* 
 * fitsBits - return 1 if x can be represented as an 
 *  n-bit, two's complement integer.
 *   1 <= n <= 32
 *   Examples: fitsBits(5,3) = 0, fitsBits(-4,3) = 1
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 15
 *   Rating: 2
 */
int fitsBits(int x, int n) {
/* 
 * flip bits if x is negative,
 * right shift n - 1 bits,
 * return false if there are still bit of 1 left
 */
  int AllLeadingBit = x >> 31;
  int flipIfNegative = (~x & AllLeadingBit) | (x & ~AllLeadingBit);
  return !(flipIfNegative >> (n + ~0));
}
/* 
 * isGreater - if x > y  then return 1, else return 0 
 *   Example: isGreater(4,5) = 0, isGreater(5,4) = 1
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 24
 *   Rating: 3
 */
int isGreater(int x, int y) {
/*
 * if x and y have same sign bits
 * x > y means (x - y) > 0, so (x + ~y + 1) > 0
 * then (x + ~y) >= 0, means (x + ~y) >> 31 == 0
 * else if if x and y have different sign bits
 * x > y means sign of x is 0 and sign of y is 1
 */
  int signX = (x >> 31) & 1;
  int signY = (y >> 31) & 1;
  int sameSign = !(signX ^ signY) & !((x + ~y) >> 31);
  int diffSign = (signX ^ signY) & ((!signX) & signY);
  return sameSign | diffSign;
}
/*
 * trueThreeFourths - multiplies by 3/4 rounding toward 0,
 *   avoiding errors due to overflow
 *   Examples: trueThreeFourths(11) = 8
 *             trueThreeFourths(-9) = -6
 *             trueThreeFourths(1073741824) = 805306368 (no overflow)
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 20
 *   Rating: 4
 */
int trueThreeFourths(int x)
/*
 * only check for last two digits
 */
{
  int sign = ~(x >> 31);
  int a = (x >> 2) + (x >> 1);
  int t = x & 3;
  int tmp1 = (1 & t);
  int tmp2 = ((2 & t)>>1);
  int b = tmp1 + tmp2 + (((~0)  + (!tmp1 & !tmp2))& sign);
  return a + b;
}
//float
/* 
 * floatIsEqual - Compute f == g for floating point arguments f and g.
 *   Both the arguments are passed as unsigned int's, but
 *   they are to be interpreted as the bit-level representations of
 *   single-precision floating point values.
 *   If either argument is NaN, return 0.
 *   +0 and -0 are considered equal.
 *   Legal ops: Any integer/unsigned operations incl. ||, &&. also if, while
 *   Max ops: 25
 *   Rating: 2
 */
int floatIsEqual(unsigned uf, unsigned ug) {
  int fe = uf & 0x7F800000;
  int fe_all_1 = !(fe ^ 0x7F800000);
  int fm = uf & 0x007FFFFF;
  int f_nan = (fm << 9) && fe_all_1;

  int ge = ug & 0x7F800000;
  int ge_all_1 = !(ge ^ 0x7F800000);
  int gm = ug & 0x007FFFFF;
  int g_nan = (gm << 9) && ge_all_1;

  if (((uf << 1) == 0) && ((ug << 1) == 0))
  {
    return 1;
  }

  if (f_nan || g_nan)
  {
    return 0;
  }

  
  return !(uf ^ ug);
}
/* 
 * floatUnsigned2Float - Return bit-level equivalent of expression (float) u
 *   Result is returned as unsigned int, but
 *   it is to be interpreted as the bit-level representation of a
 *   single-precision floating point values.
 *   Legal ops: Any integer/unsigned operations incl. ||, &&. also if, while
 *   Max ops: 30
 *   Rating: 4
 */
unsigned floatUnsigned2Float(unsigned u) {

    int count = 0;

    unsigned mask, m, g_mask, r_mask, g, r, s, e;

    while (u)
    {
        count++;
        u = u >> 1;
    }

    mask = (1 << count) - 1;

    m = mask & u;

    if (count > 24)
    {
        g_mask = 1 << (count - 24);
        r_mask = g_mask >> 1;

        g = (m & g_mask);
        r = (m & r_mask);
        s = (m & r_mask);

        if (r)
        {
            if (s || ((!s) && g))
            {
                m = m + 1;
            }
        }

    }

    e = (count + 126) << 23;

    return e | m;

}
/* 
 * floatScale4 - Return bit-level equivalent of expression 4*f for
 *   floating point argument f.
 *   Both the argument and result are passed as unsigned int's, but
 *   they are to be interpreted as the bit-level representation of
 *   single-precision floating point values.
 *   When argument is NaN, return argument
 *   Legal ops: Any integer/unsigned operations incl. ||, &&. also if, while
 *   Max ops: 30
 *   Rating: 4
 */
unsigned floatScale4(unsigned uf) {

  int s = uf & 0x80000000;
  unsigned m = uf & 0x007FFFFF;
  int e = uf & 0x7f800000;

  int e_all_1 = !(e ^ 0x7f800000);
  int e_nan = e_all_1 && (m << 9);

  if ((uf << 1) == 0)
  {
    return uf;
  }

  if (e_nan)
  {
    return uf;
  }

  if (e)
  {
    unsigned ee = e >> 23;
    unsigned result_ee = ee + 2;
    unsigned result = (result_ee << 23) | s | m;
    unsigned boundary = s ? 0xff800000 : 0x7f800000;
    return (result_ee >= 0x000000ff) ? boundary : result;
  }
  else
  {
    if (m <= 0x003fffff)
    {
      return (m << 2) | s;
    }
    else
    {
      m = (m << 1) & 0x007FFFFF;
      e = 0x01000000;
      return s | e | m;
    }
  }
}
