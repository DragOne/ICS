// Bits
int bitMatch(int, int);
int test_bitMatch(int, int);
int copyLSB(int);
int test_copyLSB(int);
int allOddBits();
int test_allOddBits();
int conditional(int, int, int);
int test_conditional(int, int, int);
int bitParity(int);
int test_bitParity(int);
int isPallindrome(int);
int test_isPallindrome(int);
// Two's complement
int distinctNegation(int);
int test_distinctNegation(int);
int dividePower2(int, int);
int test_dividePower2(int, int);
int fitsBits(int, int);
int test_fitsBits(int, int);
int isGreater(int, int);
int test_isGreater(int, int);
int trueThreeFourths(int);
int test_trueThreeFourths(int);
//float
int floatIsEqual(unsigned, unsigned);
int test_floatIsEqual(unsigned, unsigned);
unsigned floatUnsigned2Float(unsigned);
unsigned test_floatUnsigned2Float(unsigned);
unsigned floatScale4(unsigned);
unsigned test_floatScale4(unsigned);
